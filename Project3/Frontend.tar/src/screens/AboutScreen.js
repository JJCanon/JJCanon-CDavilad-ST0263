import React from 'react';

const AboutScreen = () => {
    return (
        <div>
            <p>
                Este sitio web esta concebido como una tienda virtual de obras literarias, la cual permite
                obtener el listado de obras disponibles para reservar y/o comprar. El sitio fue desarrollado 
                para que los usuarios pueda obtener información útil acerca de...   
            </p>
        </div>

    )
}

export default AboutScreen